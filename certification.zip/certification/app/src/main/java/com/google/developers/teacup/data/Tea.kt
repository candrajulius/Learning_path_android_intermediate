package com.google.developers.teacup.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.developers.teacup.data.DataTeaNames.COL_CAFFEINE
import com.google.developers.teacup.data.DataTeaNames.COL_DESCRIPTION
import com.google.developers.teacup.data.DataTeaNames.COL_FAVORITE
import com.google.developers.teacup.data.DataTeaNames.COL_ID
import com.google.developers.teacup.data.DataTeaNames.COL_INGREDIENTS
import com.google.developers.teacup.data.DataTeaNames.COL_NAME
import com.google.developers.teacup.data.DataTeaNames.COL_ORIGIN
import com.google.developers.teacup.data.DataTeaNames.COL_STEEP_TIME
import com.google.developers.teacup.data.DataTeaNames.COL_TYPE
import com.google.developers.teacup.data.DataTeaNames.TABLE_NAME

/**
 * A Model class that holds information about the tea.
 * This class defines table for the Room database with primary key {@see #mCode}
 * @see Entity
 */
@Entity(tableName = TABLE_NAME)
data class Tea(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = COL_ID)
    val id: Long = 0,
    @ColumnInfo(name = COL_NAME)
    val name: String,
    @ColumnInfo(name = COL_TYPE)
    val type: String,
    @ColumnInfo(name = COL_ORIGIN)
    val origin: String,
    @ColumnInfo(name = COL_STEEP_TIME)
    val steepTimeMs: Long,
    @ColumnInfo(name = COL_DESCRIPTION)
    val description: String,
    @ColumnInfo(name = COL_INGREDIENTS)
    val ingredients: String,
    @ColumnInfo(name = COL_CAFFEINE)
    val caffeineLevel: String,
    @ColumnInfo(name = COL_FAVORITE)
    val isFavorite: Boolean = false
)
