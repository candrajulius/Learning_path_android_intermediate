package com.google.developers.teacup.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.google.developers.teacup.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader

@Database(entities = [Tea::class], version = 1, exportSchema = false)
abstract class TeaDatabase : RoomDatabase() {

    abstract fun teaDao(): TeaDao

    companion object {

        @Volatile
        private var instance: TeaDatabase? = null

        /**
         * Returns an instance of Room Database
         *
         * @param context application context
         * @return The singleton TeaDatabase
         */
        fun getInstance(context: Context): TeaDatabase {
            return instance ?: synchronized(this){
                val INSTANCE = Room.databaseBuilder(
                    context.applicationContext,
                    TeaDatabase::class.java,
                    "tea.db"
                ).fallbackToDestructiveMigration().allowMainThreadQueries().addCallback(StartingTeas(context)).build()
                instance = INSTANCE
                INSTANCE
            }
        }

    }
}
