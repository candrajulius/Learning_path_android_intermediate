package com.google.developers.teacup.paging

import android.view.View
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.recyclerview.widget.RecyclerView
import com.google.developers.teacup.R
import com.google.developers.teacup.data.Tea

/**
 * A RecyclerView ViewHolder that displays a Tea.
 */
class TeaViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

    private val context = itemView.context
    private lateinit var tea: Tea
    private val tvTitle : TextView = itemView.findViewById(R.id.text_title)
    private val tvDescription : TextView = itemView.findViewById(R.id.text_description)
    private val tvMinutes: TextView = itemView.findViewById(R.id.text_minutes)
    private val root: ConstraintLayout = itemView.findViewById(R.id.root)

    /**
     * Attach values to views.
     */
    fun bindTo(tea: Tea, clickListener: (Tea) -> Unit) {
        tvTitle.text = tea.name
        tvDescription.text = tea.description
        tvMinutes.text = tea.steepTimeMs.toString()
        root.setOnClickListener {
            clickListener(tea)
        }
    }

    fun getTea(): Tea = tea
}
